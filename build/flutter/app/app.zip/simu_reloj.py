import flet as ft

def main(page: ft.Page):
    page.title = "Simulador de Datos (Empatica E4)"
    page.vertical_alignment = "start"
    page.padding = 20

    # --- CONFIGURACIÓN DE SENSORES ---
    configuracion_sensores = [
        {"nombre": "acc_x", "min": 40.0, "max": 70.0, "res": 0.000001, "inicio": 51.976955},
        {"nombre": "acc_y", "min": 10.0, "max": 30.0, "res": 0.000001, "inicio": 14.231976},
        {"nombre": "acc_z", "min": 20.0, "max": 40.0, "res": 0.000001, "inicio": 28.649323},
        {"nombre": "bvp",   "min": -50.0,"max": 50.0, "res": 0.01,     "inicio": 31.610494},
        {"nombre": "eda",   "min": 0.0,  "max": 5.0,  "res": 0.000001, "inicio": 1.068864},
        {"nombre": "temp",  "min": 30.0, "max": 40.0, "res": 0.01,     "inicio": 35.424470}
    ]

    # --- LISTA PARA GUARDAR VARIABLES ---
    valores = {}

    title = ft.Text("Panel de Control de Sensores", size=22, weight="bold")
    page.add(title)

    # Contenedor principal
    contenedor = ft.Column(spacing=25)

    # --- CREAR SLIDERS AUTOMÁTICAMENTE ---
    for conf in configuracion_sensores:

        # Valor inicial guardado
        valores[conf["nombre"]] = ft.Text(str(conf["inicio"]), size=14)

        # Slider
        slider = ft.Slider(
            min=conf["min"],
            max=conf["max"],
            value=conf["inicio"],
            divisions=int((conf["max"] - conf["min"]) / conf["res"]),
            label="{value}",
            on_change=lambda e, n=conf["nombre"]: actualizar_valor(n, e.control.value),
        )

        fila = ft.Column(
            [
                ft.Row([
                    ft.Text(conf["nombre"], size=16, weight="bold"),
                    valores[conf["nombre"]],
                ], alignment="spaceBetween"),
                slider
            ]
        )

        contenedor.controls.append(fila)

    page.add(contenedor)

    # --- ACCIÓN AL CAMBIAR UN SLIDER ---
    def actualizar_valor(nombre, valor):
        valores[nombre].value = f"{valor:.6f}"
        valores[nombre].update()

    # --- BOTÓN GUARDAR ---
    def guardar_dataset(e):
        datos = {nombre: float(val.value) for nombre, val in valores.items()}
        print("\n--- DATOS GUARDADOS FLET ---")
        print(datos)
        print("----------------------------\n")
        page.snack_bar = ft.SnackBar(ft.Text("¡Dataset guardado en la consola!"))
        page.snack_bar.open = True
        page.update()

    btn_guardar = ft.ElevatedButton(
        text="Guardar Dataset (JSON)",
        bgcolor="#007ACC",
        color="white",
        on_click=guardar_dataset,
    )

    page.add(ft.Divider(), btn_guardar)


ft.app(target=main)
