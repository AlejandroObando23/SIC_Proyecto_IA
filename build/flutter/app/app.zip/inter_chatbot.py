from tkinter import *
import tkinter as tk
import pyttsx3

# Bloques try-except por si faltan tus archivos externos
try:
    import aprender
    import tablaVerdad
except ImportError:
    print("Error: No se encontraron los archivos 'aprender.py' o 'tablaVerdad.py'. Asegúrate de que estén en la misma carpeta.")

# Inicialización de voz
try:
    voz = pyttsx3.init()
    voices = voz.getProperty("voices")
    # Intentar poner una voz en español si existe, sino usa la 0
    voz.setProperty("voice", voices[0].id)
except Exception as e:
    print(f"Error al configurar la voz: {e}")

def leerTexto(cadena):
    try:
        voz.say(cadena)
        voz.runAndWait()
    except:
        pass

def Abrir_Ventana2():
    ventana_Teclado = Toplevel(raiz)
    ventana_Teclado.title("Tabla de verdad")
    ventana_Teclado.config(bg="light yellow")
    
    area_Mensaje = Text(ventana_Teclado, wrap=WORD, width=50, height=20, bg="white")
    area_Mensaje.pack(fill=BOTH, expand=True, padx=10, pady=10)

    ventana_Teclado.resizable(True, True)

    mensaje_entrada = Entry(ventana_Teclado, width=40)

    def insertar_texto(texto):
        mensaje_entrada.insert(END, texto)

    # Definir las filas del teclado
    filas = [
        ('A', 'B', 'C', 'D', '∧', '∨', '~', '→', '↔', ')', '(')
    ]

    # Crear los botones del teclado
    for fila in filas:
        fila_frame = Frame(ventana_Teclado)
        fila_frame.pack(padx=5, pady=5)
        for texto in fila:
            Button(fila_frame, text=texto, width=3, height=1,
                   command=lambda t=texto: insertar_texto(t)).pack(side=LEFT, padx=5, pady=5)

    mensaje_entrada.pack(side=LEFT, fill=X, expand=True, padx=10, pady=10)

    def enviar_mensajeTabla():
        mensaje_usuario = mensaje_entrada.get()
        # Asumiendo que tablaVerdad devuelve un string
        try:
            mensaje_respuesta = tablaVerdad.tablaVerdadera(mensaje_usuario)
        except:
            mensaje_respuesta = "Error en el módulo tablaVerdad"

        area_Mensaje.insert(END, "Tú: " + mensaje_usuario + "\n")
        mensaje_entrada.delete(0, END)
        area_Mensaje.insert(END, str(mensaje_respuesta) + "\n")
        area_Mensaje.see(END)

    enviar_button = Button(ventana_Teclado, text="Enviar", command=enviar_mensajeTabla)
    enviar_button.pack(side=LEFT, padx=10, pady=10)


def Abrir_ventana():
    ventana = Toplevel(raiz)
    ventana.title("Amaya")
    ventana.config(bg="sky blue")
    
    area_Mensaje = Text(ventana, wrap=WORD, bg="light yellow")
    area_Mensaje.pack(fill=BOTH, expand=True, padx=10, pady=10)
    
    mensaje_entrada = Entry(ventana, width=40)
    mensaje_entrada.pack(side=LEFT, fill=X, expand=True, padx=10, pady=10)
    
    # Declaramos el botón 2 (Feedback) al inicio pero no lo mostramos aún
    enviar_Button2 = Button(ventana, text="Enviar Respuesta") # Se configurará dinámicamente

    def retroalimentacion(mensaje_anterior):
        respuesta_usuario = mensaje_entrada.get()
        
        # Llamada al módulo aprender
        try:
            mensaje_bot = aprender.respuesta_noconocida(respuesta_usuario, mensaje_anterior)
        except:
            mensaje_bot = "Error: No pude guardar la respuesta (Módulo aprender falló)."

        if respuesta_usuario.strip():
            area_Mensaje.insert(END, "Tú: " + respuesta_usuario + "\n")
            mensaje_entrada.delete(0, END)   
            area_Mensaje.insert(END, "Bot: " + mensaje_bot + "\n")
            area_Mensaje.see(END)
        
        # Ocultar botón de feedback y mostrar el normal
        enviar_Button2.pack_forget()
        enviar_Button.pack(side=LEFT, padx=10, pady=10)
        
        # Leer confirmación
        ventana.after(100, lambda: leerTexto(mensaje_bot))

    def enviar_Mensaje():
        mensaje_usuario = mensaje_entrada.get()
        
        try:
            mensaje_bot = aprender.chat_bot(mensaje_usuario)
        except:
            mensaje_bot = "Error: Módulo aprender no encontrado."

        mensaje_clave = mensaje_usuario.lower()

        if mensaje_usuario.strip():
            area_Mensaje.insert(END, "Tú: " + mensaje_usuario + "\n")
            mensaje_entrada.delete(0, END)
            
            # Caso 1: El bot no sabe la respuesta
            if mensaje_bot == "falso":
                texto_ayuda = "No conozco la respuesta, ¿me enseñas? Escribe la respuesta o escribe 'omitir'."
                area_Mensaje.insert(END, "Bot: " + texto_ayuda + "\n")
                area_Mensaje.see(END)
                
                # Ocultar botón normal y mostrar botón de retroalimentación
                enviar_Button.pack_forget()
                
                # Reconfiguramos el comando del botón 2 para que recuerde la pregunta original (mensaje_usuario)
                enviar_Button2.config(command=lambda: retroalimentacion(mensaje_usuario))
                enviar_Button2.pack(side=LEFT, padx=10, pady=10)
                
                ventana.after(100, lambda: leerTexto(texto_ayuda))

            # Caso 2: Abrir tabla de verdad
            elif mensaje_clave == "tablaverdad":
                area_Mensaje.insert(END, "Bot: " + mensaje_bot + "\n")
                area_Mensaje.see(END)
                Abrir_Ventana2()

            # Caso 3: Salir
            elif mensaje_clave == "salir":
                raiz.destroy()

            # Caso 4: Respuesta normal
            else:
                area_Mensaje.insert(END, "Bot: " + mensaje_bot + "\n")
                area_Mensaje.see(END)
                ventana.after(100, lambda: leerTexto(mensaje_bot))

    enviar_Button = Button(ventana, text="Enviar", command=enviar_Mensaje)
    enviar_Button.pack(side=LEFT, padx=10, pady=10)
    
    ventana.resizable(True, True)

# --- VENTANA PRINCIPAL ---
raiz = Tk()
raiz.title("Amaya")
raiz.config(bg="sky blue")
raiz.resizable(True, True)

# Manejo seguro de la imagen
try:
    logo = tk.PhotoImage(file="Amaya.png")
    label_imagen = tk.Label(raiz, image=logo)
    label_imagen.pack(pady=50, padx=100)
except Exception:
    label_error = tk.Label(raiz, text="[Imagen Amaya.png no encontrada]", bg="sky blue")
    label_error.pack(pady=50)

Label(raiz, text="Habla con Amaya", bg="sky blue", font=("courier new", 14)).pack(pady=10, padx=100)

boton = Button(raiz, text="Comenzar", command=Abrir_ventana)
boton.pack(pady=10, padx=100)

raiz.mainloop()